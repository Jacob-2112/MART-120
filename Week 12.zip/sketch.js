function setup() {
  createCanvas(500, 500);

  background(200);
  triangle(200, 225, 185, 160, 280, 220);
  triangle(250, 220, 220, 160, 300, 220);
  quad(200, 220, 150, 170, 250, 220, 200, 180);
  rect(200, 220, 100, 120, 20, 20, 100, 100);
  quad(215, 350, 300, 350, 315, 500, 210, 500);
    circle(225, 270, 40);
   circle(270, 270, 40);
  line(235, 270, 255, 270);

  textSize(22);
  fill('yellow');
  text('Jacob', 6, 20);
  fill('cornflowerblue');
  text('Blyton', 6, 45);
  fill('tomato');
  text('Jacob', 6, 70);
  fill('limegreen');
  text('Blyton', 6, 95);

  // Rotate around the y-axis.
  rotate(frameCount * 0.01);

  // Draw a line.
  line(0, 0, 0, 30, 20, -10);

  // Draw the center circle.
  circle(10);

  // Translate to the second point.
  translate(30, 20, -10);

  // Draw the bottom-right circle.
  circle(10);
  
  // Rotate around the x-axis.
  rotate(frameCount * 0.01);

  // Draw a line.
  line(0, 0, 0, 30, 20, -10);

  // Draw the center circle.
  circle(10);

  // Translate to the second point.
  translate(30, 20, -10);

  // Draw the bottom-right circle.
  circle(10);
 } 


