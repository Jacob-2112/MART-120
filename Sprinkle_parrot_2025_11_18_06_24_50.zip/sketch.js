var x = 200;
var y = 200;


function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  background(220);
    textSize(50)
  text("exit", 270, 370);
  ellipse(x,y,30,30);
  rect(90, 120, 55, 55);
  rect(240, 220, 60, 75)

  
  //x = x + 1;
  if (x >= 400){
   x = 0; 
  }
 
}
function keyPressed() {
  if (keyCode === UP_ARROW) {
    y = y - 10;
  } else if (keyCode === DOWN_ARROW) {
   y = y + 10;
  }
  if (keyCode === LEFT_ARROW) {
    x = x - 5;
  } else if (keyCode === RIGHT_ARROW) {
    x = x + 5;
  }
  
}

 
